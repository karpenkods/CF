<?php
$cms = require_once $_SERVER['DOCUMENT_ROOT'] . '/init.php';
$cms->landing(26, 59); //topsykey
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>LetterLift</title>
  <meta name="description"
    content="Create compelling motivational letters, cover letters, and professional communications with AI-powered templates and writing assistance." />
  <link rel="icon" type="image/svg+xml" href="icons/favicon.webp" />
  <link rel="stylesheet" href="css/styles.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
  <?php $cms->header(); ?>
</head>

<body>
  <!-- GDPR Banner -->
  <div id="gdpr-banner" class="gdpr-banner">
    <div class="gdpr-content">
      <div>
        <h4>We use cookies</h4>
        <p>
          This website uses cookies to improve your experience and analyze
          traffic. By continuing to use the site, you agree to our use of
          cookies.
          <a href="cookie-policy.php">Learn more</a>
        </p>
      </div>
      <div class="gdpr-buttons">
        <button id="accept-all" class="gdpr-btn accept">Accept All</button>
        <button id="customize" class="gdpr-btn customize">Customize</button>
        <button id="reject-all" class="gdpr-btn reject">Reject All</button>
      </div>
    </div>
  </div>

  <!-- Header -->
  <header class="header">
    <div class="container">
      <div class="header-content">
        <div class="logo">
          <a href="index.php">
            <img src="icons/logo-header.webp" alt="LetterLift" class="logo-img" />
          </a>
        </div>
        <nav class="nav">
          <ul class="nav-list">
            <li><a href="index.php">Home</a></li>
            <li><a href="#how-it-works">How It Works</a></li>
            <li><a href="#benefits">Benefits</a></li>
            <li><a href="#pricing">Pricing</a></li>
            <li><a href="about.php">About Us</a></li>
          </ul>
        </nav>
        <div class="header-cta">
          <a href="#pricing" class="btn btn-primary">Get Started</a>
        </div>
      </div>
    </div>
  </header>

  <!-- Hero Section -->
  <section id="home" class="hero">
    <div class="container">
      <div class="hero-content">
        <div class="hero-text">
          <h2 class="hero-subtitle">
            Professional Letter Writing Made Simple
          </h2>
          <h1 class="hero-title">
            Transform Your Ideas Into Compelling Letters
          </h1>
          <p class="hero-description">
            Create professional motivational letters, cover letters, and
            business communications with our AI-powered platform. Stand out
            from the crowd with expertly crafted content that gets results.
          </p>

          <ul class="hero-bullets">
            <li>500+ Professional Templates</li>
            <li>AI-Powered Writing Assistant</li>
            <li>Industry-Specific Content</li>
            <li>Instant Download & Customization</li>
          </ul>

          <div class="hero-cta">
            <a href="#pricing" class="btn btn-primary btn-large">Start Writing Today</a>
          </div>
        </div>
        <div class="hero-image">
          <img src="images/hero-image.png" alt="Professional Letter Writing" class="hero-img" loading="lazy" />
        </div>
      </div>
    </div>
  </section>

  <!-- How It Works Section -->
  <section id="how-it-works" class="how-it-works">
    <div class="container">
      <div class="section-header">
        <h2 class="section-title">How LetterLift Works</h2>
        <p class="section-subtitle">
          Create professional letters in three simple steps
        </p>
      </div>
      <div class="steps">
        <div class="step">
          <div class="step-number">1</div>
          <div class="step-icon">
            <img src="icons/template-icon.webp" alt="Choose Template" />
          </div>
          <h3 class="step-title">Choose Your Template</h3>
          <p class="step-description">
            Select from our extensive library of professional templates
            designed for various industries and purposes.
          </p>
        </div>
        <div class="step">
          <div class="step-number">2</div>
          <div class="step-icon">
            <img src="icons/customize-icon.webp" alt="Customize Content" />
          </div>
          <h3 class="step-title">Customize with AI</h3>
          <p class="step-description">
            Use our AI-powered writing assistant to personalize your letter
            with compelling content tailored to your specific needs.
          </p>
        </div>
        <div class="step">
          <div class="step-number">3</div>
          <div class="step-icon">
            <img src="icons/download-icon.webp" alt="Download Letter" />
          </div>
          <h3 class="step-title">Download & Send</h3>
          <p class="step-description">
            Download your professionally formatted letter in multiple formats
            and send it with confidence.
          </p>
        </div>
      </div>
    </div>
  </section>

  <!-- Benefits Section -->
  <section id="benefits" class="benefits">
    <div class="container">
      <div class="section-header">
        <h2 class="section-title">Why Choose LetterLift?</h2>
        <p class="section-subtitle">
          Discover the advantages that make us the preferred choice for
          professional letter writing
        </p>
      </div>
      <div class="benefits-grid">
        <div class="benefit-card">
          <div class="benefit-icon">
            <img src="icons/time-icon.webp" alt="Save Time" />
          </div>
          <h3 class="benefit-title">Save Time</h3>
          <p class="benefit-description">
            Create professional letters in minutes, not hours. Our streamlined
            process eliminates writer's block and speeds up your workflow.
          </p>
        </div>
        <div class="benefit-card">
          <div class="benefit-icon">
            <img src="icons/professional-icon.webp" alt="Professional Quality" />
          </div>
          <h3 class="benefit-title">Professional Quality</h3>
          <p class="benefit-description">
            Every template is crafted by professional writers and reviewed by
            industry experts to ensure maximum impact.
          </p>
        </div>
        <div class="benefit-card">
          <div class="benefit-icon">
            <img src="icons/ai-icon.webp" alt="AI-Powered" />
          </div>
          <h3 class="benefit-title">AI-Powered Assistance</h3>
          <p class="benefit-description">
            Our advanced AI helps you craft compelling content that resonates
            with your audience and achieves your goals.
          </p>
        </div>
        <div class="benefit-card">
          <div class="benefit-icon">
            <img src="icons/customization-icon.webp" alt="Full Customization" />
          </div>
          <h3 class="benefit-title">Full Customization</h3>
          <p class="benefit-description">
            Tailor every aspect of your letter to match your personal style,
            brand, and specific requirements.
          </p>
        </div>
        <div class="benefit-card">
          <div class="benefit-icon">
            <img src="icons/templates-icon.webp" alt="Extensive Library" />
          </div>
          <h3 class="benefit-title">Extensive Library</h3>
          <p class="benefit-description">
            Access hundreds of templates covering every industry, purpose, and
            communication style you might need.
          </p>
        </div>
        <div class="benefit-card">
          <div class="benefit-icon">
            <img src="icons/results-icon.webp" alt="Proven Results" />
          </div>
          <h3 class="benefit-title">Proven Results</h3>
          <p class="benefit-description">
            Our users report higher response rates and better outcomes when
            using LetterLift-generated communications.
          </p>
        </div>
      </div>
    </div>
  </section>

  <!-- Use Cases Section -->
  <section class="use-cases">
    <div class="container">
      <div class="section-header">
        <h2 class="section-title">Perfect for Every Situation</h2>
        <p class="section-subtitle">
          Whatever your communication needs, we have the right template and
          tools
        </p>
      </div>
      <div class="use-cases-grid">
        <div class="use-case-card">
          <div class="use-case-icon">
            <img src="icons/job-icon.webp" alt="Job Applications" />
          </div>
          <h3 class="use-case-title">Job Applications</h3>
          <p class="use-case-description">
            Stand out with compelling cover letters and follow-up
            communications that showcase your unique value proposition.
          </p>
        </div>
        <div class="use-case-card">
          <div class="use-case-icon">
            <img src="icons/scholarship-icon.webp" alt="Scholarship Applications" />
          </div>
          <h3 class="use-case-title">Scholarship Applications</h3>
          <p class="use-case-description">
            Craft persuasive scholarship essays and motivational letters that
            highlight your achievements and aspirations.
          </p>
        </div>
        <div class="use-case-card">
          <div class="use-case-icon">
            <img src="icons/business-icon.webp" alt="Business Communications" />
          </div>
          <h3 class="use-case-title">Business Communications</h3>
          <p class="use-case-description">
            Create professional business letters, proposals, and
            correspondence that drive results and build relationships.
          </p>
        </div>
        <div class="use-case-card">
          <div class="use-case-icon">
            <img src="icons/academic-icon.webp" alt="Academic Appeals" />
          </div>
          <h3 class="use-case-title">Academic Appeals</h3>
          <p class="use-case-description">
            Write compelling academic appeals, admission letters, and
            recommendation requests with confidence.
          </p>
        </div>
        <div class="use-case-card">
          <div class="use-case-icon">
            <img src="icons/grant-icon.webp" alt="Grant Applications" />
          </div>
          <h3 class="use-case-title">Grant Applications</h3>
          <p class="use-case-description">
            Develop persuasive grant proposals and funding requests that
            clearly communicate your project's value.
          </p>
        </div>
        <div class="use-case-card">
          <div class="use-case-icon">
            <img src="icons/personal-icon.webp" alt="Personal Appeals" />
          </div>
          <h3 class="use-case-title">Personal Appeals</h3>
          <p class="use-case-description">
            Handle sensitive personal communications with tact and
            professionalism for the best possible outcomes.
          </p>
        </div>
      </div>
    </div>
  </section>

  <!-- CTA Section -->
  <section class="cta-section">
    <div class="container">
      <h2 class="cta-title">Ready to Transform Your Writing?</h2>
      <p class="cta-subtitle">
        Join thousands of professionals who trust LetterLift to create
        compelling, results-driven letters
      </p>
      <a href="#pricing" class="btn btn-primary btn-large">View Pricing Plans</a>
    </div>
  </section>

  <!-- Pricing Section -->
  <section id="pricing" class="pricing">
    <div class="container">
      <div class="section-header">
        <h2 class="section-title">Choose Your Plan</h2>
        <p class="section-subtitle">
          Select the perfect plan for your letter writing needs
        </p>
      </div>

      <div class="pricing-switcher">
        <button class="pricing-level active" data-level="basic">Basic</button>
        <button class="pricing-level" data-level="advanced">Advanced</button>
        <button class="pricing-level" data-level="professional">
          Professional
        </button>
      </div>
    </div>

    <div class="pricing-cards">
      <!-- Basic Level -->
      <div class="pricing-level-cards active" data-level="basic">
        <div class="pricing-card">
          <h3 class="plan-name">Starter</h3>
          <div class="plan-price">$1.99<span>/month</span></div>
          <p class="plan-description">
            Perfect for getting started with letter writing
          </p>
          <ul class="plan-features">
            <li>10+ basic templates</li>
            <li>Simple writing tools</li>
            <li>Up to 3 letters per month</li>
            <li>Email support</li>
          </ul>
          <button class="btn btn-primary plan-btn" data-plan="Starter" data-price="1.99">
            Get Started
          </button>
        </div>

        <div class="pricing-card">
          <h3 class="plan-name">Essential</h3>
          <div class="plan-price">$9.99<span>/month</span></div>
          <p class="plan-description">
            Essential tools for regular letter writing
          </p>
          <ul class="plan-features">
            <li>50+ professional templates</li>
            <li>Basic AI writing assistance</li>
            <li>Up to 15 letters per month</li>
            <li>Priority email support</li>
          </ul>
          <button class="btn btn-primary plan-btn" data-plan="Essential" data-price="9.99">
            Get Started
          </button>
        </div>

        <div class="pricing-card">
          <h3 class="plan-name">Standard</h3>
          <div class="plan-price">$19.50<span>/month</span></div>
          <p class="plan-description">Standard features for frequent users</p>
          <ul class="plan-features">
            <li>100+ professional templates</li>
            <li>Enhanced AI assistance</li>
            <li>Up to 30 letters per month</li>
            <li>Phone and email support</li>
          </ul>
          <button class="btn btn-primary plan-btn" data-plan="Standard" data-price="19.50">
            Get Started
          </button>
        </div>

        <div class="pricing-card">
          <h3 class="plan-name">Plus</h3>
          <div class="plan-price">$29.90<span>/month</span></div>
          <p class="plan-description">Enhanced features for active writers</p>
          <ul class="plan-features">
            <li>150+ professional templates</li>
            <li>Advanced AI writing tools</li>
            <li>Up to 50 letters per month</li>
            <li>Priority support with chat</li>
          </ul>
          <button class="btn btn-primary plan-btn" data-plan="Plus" data-price="29.90">
            Get Started
          </button>
        </div>
      </div>

      <!-- Advanced Level -->
      <div class="pricing-level-cards" data-level="advanced">
        <div class="pricing-card">
          <h3 class="plan-name">Professional</h3>
          <div class="plan-price">$39.99<span>/month</span></div>
          <p class="plan-description">
            Professional tools for serious writers
          </p>
          <ul class="plan-features">
            <li>200+ professional templates</li>
            <li>Advanced AI writing assistance</li>
            <li>Up to 100 letters per month</li>
            <li>Custom branding options</li>
          </ul>
          <button class="btn btn-primary plan-btn" data-plan="Professional" data-price="39.99">
            Get Started
          </button>
        </div>

        <div class="pricing-card">
          <h3 class="plan-name">Premium</h3>
          <div class="plan-price">$49.50<span>/month</span></div>
          <p class="plan-description">Premium features for demanding users</p>
          <ul class="plan-features">
            <li>300+ professional templates</li>
            <li>Premium AI writing tools</li>
            <li>Unlimited letters per month</li>
            <li>Industry-specific templates</li>
          </ul>
          <button class="btn btn-primary plan-btn" data-plan="Premium" data-price="49.50">
            Get Started
          </button>
        </div>

        <div class="pricing-card">
          <h3 class="plan-name">Business</h3>
          <div class="plan-price">$59.90<span>/month</span></div>
          <p class="plan-description">Business-grade solution for teams</p>
          <ul class="plan-features">
            <li>400+ business templates</li>
            <li>Team collaboration tools</li>
            <li>Unlimited letters per month</li>
            <li>Advanced analytics</li>
          </ul>
          <button class="btn btn-primary plan-btn" data-plan="Business" data-price="59.90">
            Get Started
          </button>
        </div>

        <div class="pricing-card">
          <h3 class="plan-name">Corporate</h3>
          <div class="plan-price">$69.99<span>/month</span></div>
          <p class="plan-description">
            Corporate solution with full features
          </p>
          <ul class="plan-features">
            <li>500+ corporate templates</li>
            <li>Enterprise AI assistance</li>
            <li>Unlimited everything</li>
            <li>Dedicated account manager</li>
          </ul>
          <button class="btn btn-primary plan-btn" data-plan="Corporate" data-price="69.99">
            Get Started
          </button>
        </div>
      </div>

      <!-- Professional Level -->
      <div class="pricing-level-cards" data-level="professional">
        <div class="pricing-card">
          <h3 class="plan-name">Executive</h3>
          <div class="plan-price">$79.50<span>/month</span></div>
          <p class="plan-description">Executive-level writing solutions</p>
          <ul class="plan-features">
            <li>600+ executive templates</li>
            <li>Executive AI writing coach</li>
            <li>Unlimited premium features</li>
            <li>White-glove support</li>
          </ul>
          <button class="btn btn-primary plan-btn" data-plan="Executive" data-price="79.50">
            Get Started
          </button>
        </div>

        <div class="pricing-card">
          <h3 class="plan-name">Enterprise</h3>
          <div class="plan-price">$89.90<span>/month</span></div>
          <p class="plan-description">
            Enterprise solution for large organizations
          </p>
          <ul class="plan-features">
            <li>700+ enterprise templates</li>
            <li>Custom AI training</li>
            <li>API access and integrations</li>
            <li>On-site training available</li>
          </ul>
          <button class="btn btn-primary plan-btn" data-plan="Enterprise" data-price="89.90">
            Get Started
          </button>
        </div>

        <div class="pricing-card">
          <h3 class="plan-name">Ultimate</h3>
          <div class="plan-price">$99.99<span>/month</span></div>
          <p class="plan-description">
            Ultimate writing platform with everything
          </p>
          <ul class="plan-features">
            <li>800+ premium templates</li>
            <li>Personalized AI assistant</li>
            <li>Custom template creation</li>
            <li>24/7 priority support</li>
          </ul>
          <button class="btn btn-primary plan-btn" data-plan="Ultimate" data-price="99.99">
            Get Started
          </button>
        </div>

        <div class="pricing-card">
          <h3 class="plan-name">Elite</h3>
          <div class="plan-price">$109.50<span>/month</span></div>
          <p class="plan-description">Elite tier with exclusive features</p>
          <ul class="plan-features">
            <li>1000+ exclusive templates</li>
            <li>Elite AI writing consultant</li>
            <li>Bespoke solutions</li>
            <li>Concierge-level service</li>
          </ul>
          <button class="btn btn-primary plan-btn" data-plan="Elite" data-price="109.50">
            Get Started
          </button>
        </div>
      </div>
    </div>
  </section>

  <!-- Contact Form Section -->
  <section class="contact-form-section">
    <div class="container">
      <div class="section-header">
        <h2 class="section-title">Get in Touch</h2>
        <p class="section-subtitle">
          Have questions? We're here to help you succeed
        </p>
      </div>
      <div class="contact-form-container">
        <form class="contact-form" id="contact-form">
          <h3>Send us a Message</h3>
          <div class="form-group">
            <label for="name">Name *</label>
            <input type="text" id="name" name="name" required />
          </div>
          <div class="form-group">
            <label for="phone">Phone Number *</label>
            <input type="tel" id="phone" name="phone" required />
          </div>
          <div class="form-group">
            <label for="email">Email *</label>
            <input type="email" id="email" name="email" required />
          </div>
          <div class="form-group">
            <label for="message">Message</label>
            <textarea id="message" name="message" rows="6" placeholder="Tell us how we can help you..."></textarea>
          </div>
          <button type="submit" class="btn btn-primary btn-large">
            Send Message
          </button>
        </form>

        <div class="contact-info">
          <h3>Contact Information</h3>
          <p>
            We're here to help you create compelling letters that get results.
            Reach out to us through any of the channels below.
          </p>

          <ul>
            <li>
              Email:
              <a href="mailto:support@letterliftapp.com">support@letterliftapp.com</a>
            </li>
            <li>Phone: <a href="tel:+14243250598">+1 (424) 325-05-98</a></li>
            <li>Business Hours: Monday to Friday, 9AM to 6PM EST</li>
            <li>
              Address: 1230 Rosecrans Ave Suite 300, Manhattan Beach, CA 90266
            </li>
          </ul>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="footer">
    <div class="container">
      <div class="footer-content">
        <div class="footer-brand">
          <a href="index.php">
            <img src="icons/logo-footer.webp" alt="LetterLift" class="footer-logo" />
          </a>
          <p class="footer-slogan">Professional letters made simple</p>
        </div>
        <div class="footer-column">
          <h4>Links</h4>
          <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="#how-it-works">How It Works</a></li>
            <li><a href="#benefits">Benefits</a></li>
            <li><a href="#pricing">Pricing</a></li>
            <li><a href="about.php">About Us</a></li>
            <!-- <li><a href="contact.php">Contact Us</a></li> -->
          </ul>
        </div>
        <div class="footer-column">
          <h4>Legal</h4>
          <ul>
            <li><a href="privacy-policy.php">Privacy Policy</a></li>
            <li><a href="terms-of-service.php">Terms of Service</a></li>
            <li><a href="cookie-policy.php">Cookie Policy</a></li>
            <li><a href="refund-policy.php">Refund Policy</a></li>
            <li>
              <a href="cancel-subscription.php">Cancel Subscription</a>
            </li>
          </ul>
        </div>
        <div class="footer-column">
          <h4>Contact</h4>
          <ul>
            <li><a href="contact.php">Contact Us</a></li>
            <li>
              <a href="mailto:support@letterliftapp.com">support@letterliftapp.com</a>
            </li>
            <li><a href="tel:+14243250598">+1 (424) 325-05-98</a></li>
            <li>
              1230 Rosecrans Ave Suite 300<br />Manhattan Beach, CA 90266
            </li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">
        <p>&copy; 2025 LetterLift. All rights reserved.</p>
        <p>LetterLift is a service of Noventra Consulting Group</p>
      </div>
    </div>
  </footer>

  <!-- Pop-up Modals -->
  <div id="contact-success-modal" class="modal">
    <div class="modal-content">
      <h3>Thank You!</h3>
      <p>We will contact you shortly</p>
      <button class="btn btn-primary modal-close">Close</button>
    </div>
  </div>

  <div id="payment-success-modal" class="modal">
    <div class="modal-content">
      <h3>Payment Successful!</h3>
      <p>
        Your purchase has been confirmed. Thank you for choosing LetterLift!
      </p>
      <button class="btn btn-primary modal-close">OK</button>
    </div>
  </div>

  <div id="subscription-canceled-modal" class="modal">
    <div class="modal-content">
      <h3>Subscription Canceled</h3>
      <p>Your subscription has been canceled successfully</p>
      <button class="btn btn-primary modal-close">Close</button>
    </div>
  </div>

  <script src="js/main.js"></script>
  <?php $cms->footer(); ?>
</body>

</html>