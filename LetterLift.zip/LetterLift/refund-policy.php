<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>LetterLift</title>
    <link rel="icon" type="image/svg+xml" href="icons/favicon.webp" />
    <link rel="stylesheet" href="css/styles.css" />
  </head>
  <body>
    <!-- GDPR Banner -->
    <div id="gdpr-banner" class="gdpr-banner">
      <div class="gdpr-content">
        <div>
          <h4>We use cookies</h4>
          <p>
            This website uses cookies to improve your experience and analyze
            traffic. By continuing to use the site, you agree to our use of
            cookies.
            <a href="cookie-policy.php">Learn more</a>
          </p>
        </div>
        <div class="gdpr-buttons">
          <button id="accept-all" class="gdpr-btn accept">Accept All</button>
          <button id="customize" class="gdpr-btn customize">Customize</button>
          <button id="reject-all" class="gdpr-btn reject">Reject All</button>
        </div>
      </div>
    </div>

    <!-- Header -->
    <header class="header">
      <div class="container">
        <div class="header-content">
          <div class="logo">
            <a href="index.php">
              <img
                src="icons/logo-header.webp"
                alt="LetterLift"
                class="logo-img"
              />
            </a>
          </div>
          <nav class="nav">
            <ul class="nav-list">
              <li><a href="index.php">Home</a></li>
              <li><a href="index.php#how-it-works">How It Works</a></li>
              <li><a href="index.php#benefits">Benefits</a></li>
              <li><a href="index.php#pricing">Pricing</a></li>
              <li><a href="about.php">About Us</a></li>
            </ul>
          </nav>
          <div class="header-cta">
            <a href="index.php#pricing" class="btn btn-primary">Get Started</a>
          </div>
        </div>
      </div>
    </header>

    <!-- Refund Policy Content -->
    <main class="legal-page">
      <div class="container">
        <div class="legal-content">
          <h1>Refund Policy</h1>
          <p class="last-updated">Last Updated: April 8, 2025</p>

          <div class="legal-section">
            <h2>1. Introduction</h2>
            <p>
              This Refund Policy outlines the terms and conditions under which
              Noventra Consulting Group ("we," "us," or "our"), the operator of
              LetterLift ("Service"), provides refunds for subscription fees and
              other charges. This policy is designed to be fair to both our
              customers and our business while complying with applicable
              consumer protection laws in the United States.
            </p>

            <p>
              By subscribing to our Service, you acknowledge that you have read,
              understood, and agree to be bound by this Refund Policy in
              conjunction with our Terms of Service and Privacy Policy.
            </p>
          </div>

          <div class="legal-section">
            <h2>2. Subscription Refund Eligibility</h2>

            <h3>2.1 30-Day Money-Back Guarantee</h3>
            <p>
              We offer a 30-day money-back guarantee for all new subscribers. If
              you are not satisfied with our Service for any reason, you may
              request a full refund within 30 days of your initial subscription
              date.
            </p>

            <h3>2.2 Eligibility Requirements</h3>
            <p>
              To be eligible for a refund under our 30-day guarantee, you must:
            </p>
            <ul>
              <li>Be a first-time subscriber to LetterLift</li>
              <li>
                Request the refund within 30 calendar days of your initial
                subscription
              </li>
              <li>
                Have used the Service in good faith and in accordance with our
                Terms of Service
              </li>
              <li>Not have violated any terms of our Terms of Service</li>
              <li>Not have previously received a refund from LetterLift</li>
            </ul>

            <h3>2.3 Partial Month Refunds</h3>
            <p>
              For subscriptions canceled after the 30-day guarantee period, we
              do not provide prorated refunds for partial months. Your
              subscription will remain active until the end of your current
              billing cycle.
            </p>
          </div>

          <div class="legal-section">
            <h2>3. Refund Process and Timeline</h2>

            <h3>3.1 How to Request a Refund</h3>
            <p>
              To request a refund, you must contact our customer support team
              through one of the following methods:
            </p>
            <ul>
              <li>
                <strong>Email:</strong>
                <a href="mailto:support@letterliftapp.com"
                  >support@letterliftapp.com</a
                >
              </li>
              <li>
                <strong>Phone:</strong>
                <a href="tel:+14243250598">+1 (424) 325-05-98</a>
              </li>
              <li>
                <strong>Online Form:</strong> Submit a request through our
                contact form
              </li>
              <li>
                <strong>Mail:</strong> 1230 Rosecrans Ave Suite 300, Manhattan
                Beach, CA 90266
              </li>
            </ul>

            <h3>3.2 Required Information</h3>
            <p>When requesting a refund, please provide:</p>
            <ul>
              <li>
                Your full name and email address associated with the account
              </li>
              <li>Your subscription plan and billing information</li>
              <li>The reason for your refund request</li>
              <li>Any relevant order or transaction numbers</li>
              <li>The date of your initial subscription</li>
            </ul>

            <h3>3.3 Processing Timeline</h3>
            <ul>
              <li>
                <strong>Acknowledgment:</strong> We will acknowledge your refund
                request within 24 hours
              </li>
              <li>
                <strong>Review:</strong> We will review your request within 3-5
                business days
              </li>
              <li>
                <strong>Decision:</strong> You will receive a decision within 7
                business days
              </li>
              <li>
                <strong>Processing:</strong> Approved refunds will be processed
                within 5-10 business days
              </li>
              <li>
                <strong>Receipt:</strong> Refunds typically appear in your
                account within 3-7 business days after processing
              </li>
            </ul>
          </div>

          <div class="legal-section">
            <h2>4. Refund Methods</h2>

            <h3>4.1 Original Payment Method</h3>
            <p>
              Refunds will be issued to the original payment method used for the
              subscription. This includes:
            </p>
            <ul>
              <li>
                Credit cards (Visa, Mastercard, American Express, Discover)
              </li>
              <li>Debit cards</li>
              <li>PayPal accounts</li>
              <li>Bank transfers (where applicable)</li>
            </ul>

            <h3>4.2 Alternative Refund Methods</h3>
            <p>
              In cases where the original payment method is no longer available,
              we may issue refunds through:
            </p>
            <ul>
              <li>Bank transfer to a verified account</li>
              <li>Check mailed to your billing address</li>
              <li>Store credit (with your consent)</li>
            </ul>

            <h3>4.3 Processing Fees</h3>
            <p>
              We do not charge processing fees for legitimate refund requests.
              However, third-party payment processors may retain their original
              processing fees, which are beyond our control.
            </p>
          </div>

          <div class="legal-section">
            <h2>5. Circumstances for Refunds</h2>

            <h3>5.1 Eligible Refund Scenarios</h3>
            <p>
              We will consider refund requests in the following circumstances:
            </p>
            <ul>
              <li>Technical issues that prevent you from using the Service</li>
              <li>Service outages lasting more than 24 hours</li>
              <li>Billing errors or duplicate charges</li>
              <li>Unauthorized charges on your account</li>
              <li>Failure to deliver promised features or functionality</li>
              <li>Dissatisfaction within the 30-day guarantee period</li>
            </ul>

            <h3>5.2 Non-Eligible Refund Scenarios</h3>
            <p>
              We generally do not provide refunds in the following
              circumstances:
            </p>
            <ul>
              <li>Change of mind after the 30-day guarantee period</li>
              <li>Failure to use the Service due to personal circumstances</li>
              <li>Violation of our Terms of Service</li>
              <li>Requests made more than 30 days after subscription</li>
              <li>Abuse of the refund policy</li>
              <li>Chargebacks initiated without contacting us first</li>
            </ul>

            <h3>5.3 Exceptional Circumstances</h3>
            <p>
              We may consider refunds outside our standard policy in exceptional
              circumstances, such as:
            </p>
            <ul>
              <li>Medical emergencies or serious illness</li>
              <li>Military deployment</li>
              <li>
                Natural disasters affecting your ability to use the Service
              </li>
              <li>Death of the subscriber</li>
            </ul>
            <p>
              Such requests will be evaluated on a case-by-case basis and may
              require supporting documentation.
            </p>
          </div>

          <div class="legal-section">
            <h2>6. Subscription Cancellation</h2>

            <h3>6.1 How to Cancel</h3>
            <p>You can cancel your subscription at any time through:</p>
            <ul>
              <li>Your account settings on our website</li>
              <li>Contacting customer support</li>
              <li>Using our cancellation form</li>
              <li>Calling our support line</li>
            </ul>

            <h3>6.2 Cancellation Effective Date</h3>
            <p>
              Cancellations take effect at the end of your current billing
              cycle. You will continue to have access to the Service until that
              date.
            </p>

            <h3>6.3 Reactivation</h3>
            <p>
              You may reactivate your subscription at any time, but previous
              refund eligibility periods do not reset.
            </p>
          </div>

          <div class="legal-section">
            <h2>7. Billing Disputes and Chargebacks</h2>

            <h3>7.1 Contact Us First</h3>
            <p>
              Before initiating a chargeback with your bank or credit card
              company, please contact us directly. Most billing issues can be
              resolved quickly and amicably through direct communication.
            </p>

            <h3>7.2 Chargeback Consequences</h3>
            <p>If you initiate a chargeback without first contacting us:</p>
            <ul>
              <li>Your account may be immediately suspended</li>
              <li>
                You may be charged additional fees to cover chargeback costs
              </li>
              <li>Future refund requests may be denied</li>
              <li>Legal action may be taken to recover costs</li>
            </ul>

            <h3>7.3 Fraudulent Chargebacks</h3>
            <p>
              Chargebacks initiated after receiving our services without
              attempting to resolve the issue directly may be considered
              fraudulent and will be disputed accordingly.
            </p>
          </div>

          <div class="legal-section">
            <h2>8. Student and Educational Discounts</h2>

            <h3>8.1 Student Verification</h3>
            <p>
              Student discounts require valid student identification. If student
              status cannot be verified, the discount may be revoked and
              additional charges may apply.
            </p>

            <h3>8.2 Student Refund Policy</h3>
            <p>
              Student subscriptions are subject to the same refund policy as
              regular subscriptions, with the following additions:
            </p>
            <ul>
              <li>
                Refunds may be denied if student status was misrepresented
              </li>
              <li>
                Graduation or change in student status does not qualify for
                refunds
              </li>
              <li>
                Academic calendar changes do not affect refund eligibility
              </li>
            </ul>
          </div>

          <div class="legal-section">
            <h2>9. Business and Enterprise Refunds</h2>

            <h3>9.1 Business Account Refunds</h3>
            <p>
              Business and Enterprise accounts may have custom refund terms
              outlined in their service agreements. These terms take precedence
              over this general policy.
            </p>

            <h3>9.2 Volume Discounts</h3>
            <p>
              Accounts receiving volume discounts may have different refund
              calculations based on actual usage and the discount structure.
            </p>

            <h3>9.3 Custom Contracts</h3>
            <p>
              Enterprise customers with custom contracts should refer to their
              specific agreement terms for refund policies.
            </p>
          </div>

          <div class="legal-section">
            <h2>10. Technical Issues and Service Credits</h2>

            <h3>10.1 Service Level Agreement</h3>
            <p>
              We strive to maintain 99.9% uptime for our Service. In cases of
              extended outages, we may provide service credits or refunds as
              follows:
            </p>
            <ul>
              <li><strong>4-24 hours downtime:</strong> 10% service credit</li>
              <li><strong>24-48 hours downtime:</strong> 25% service credit</li>
              <li>
                <strong>48+ hours downtime:</strong> 50% service credit or full
                refund
              </li>
            </ul>

            <h3>10.2 Planned Maintenance</h3>
            <p>
              Scheduled maintenance periods do not qualify for service credits
              or refunds, provided reasonable notice is given.
            </p>

            <h3>10.3 Third-Party Issues</h3>
            <p>
              Service interruptions caused by third-party providers (internet,
              hosting, etc.) may not qualify for refunds unless the outage
              exceeds 48 hours.
            </p>
          </div>

          <div class="legal-section">
            <h2>11. Refund Abuse Prevention</h2>

            <h3>11.1 Monitoring</h3>
            <p>We monitor refund requests for patterns of abuse, including:</p>
            <ul>
              <li>Multiple refund requests from the same user</li>
              <li>Suspicious account activity</li>
              <li>Violation of Terms of Service</li>
              <li>Fraudulent payment methods</li>
            </ul>

            <h3>11.2 Consequences of Abuse</h3>
            <p>Users who abuse our refund policy may face:</p>
            <ul>
              <li>Denial of future refund requests</li>
              <li>Account suspension or termination</li>
              <li>Legal action to recover costs</li>
              <li>Reporting to relevant authorities</li>
            </ul>
          </div>

          <div class="legal-section">
            <h2>12. State-Specific Rights</h2>

            <h3>12.1 California Residents</h3>
            <p>
              California residents have additional rights under the California
              Consumer Privacy Act (CCPA) and other state laws. These rights do
              not affect your refund eligibility but provide additional consumer
              protections.
            </p>

            <h3>12.2 Other State Laws</h3>
            <p>
              Some states have specific consumer protection laws that may
              provide additional refund rights. This policy does not limit any
              rights you may have under applicable state law.
            </p>

            <h3>12.3 Federal Protections</h3>
            <p>
              Federal laws, including the Fair Credit Billing Act, provide
              additional protections for billing disputes and unauthorized
              charges.
            </p>
          </div>

          <div class="legal-section">
            <h2>13. International Customers</h2>

            <h3>13.1 Currency and Exchange Rates</h3>
            <p>
              Refunds for international customers will be processed in the
              original currency. Exchange rate fluctuations may affect the final
              amount received.
            </p>

            <h3>13.2 International Banking</h3>
            <p>
              International refunds may take longer to process due to banking
              regulations and may incur additional fees from intermediary banks.
            </p>

            <h3>13.3 Local Laws</h3>
            <p>
              International customers may have additional rights under their
              local consumer protection laws, which this policy does not limit.
            </p>
          </div>

          <div class="legal-section">
            <h2>14. Changes to This Refund Policy</h2>

            <p>
              We may update this Refund Policy from time to time to reflect
              changes in our business practices, legal requirements, or other
              factors. Changes will be communicated through:
            </p>
            <ul>
              <li>Email notifications to active subscribers</li>
              <li>Prominent notices on our website</li>
              <li>Updates to this page with revision dates</li>
            </ul>

            <p>
              Material changes that reduce refund eligibility will not apply to
              subscriptions purchased before the change takes effect.
            </p>
          </div>

          <div class="legal-section">
            <h2>15. Contact Information</h2>

            <p>
              For refund requests, billing questions, or concerns about this
              policy, please contact us:
            </p>

            <div class="contact-details">
              <p>
                <strong>Noventra Consulting Group</strong><br />
                Attention: Billing Department<br />
                1230 Rosecrans Ave Suite 300<br />
                Manhattan Beach, CA 90266
              </p>

              <p>
                <strong>Email:</strong>
                <a href="mailto:support@letterliftapp.com"
                  >support@letterliftapp.com</a
                ><br />
                <strong>Phone:</strong>
                <a href="tel:+14243250598">+1 (424) 325-05-98</a><br />
                <strong>Business Hours:</strong> Monday to Friday, 9AM to 6PM
                EST
              </p>
            </div>
          </div>

          <div class="legal-section">
            <h2>16. Effective Date</h2>

            <p>
              This Refund Policy is effective as of April 8, 2025, and applies
              to all subscriptions and transactions processed on or after this
              date.
            </p>
          </div>
        </div>
      </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
      <div class="container">
        <div class="footer-content">
          <div class="footer-brand">
            <a href="index.php">
              <img
                src="icons/logo-footer.webp"
                alt="LetterLift"
                class="footer-logo"
              />
            </a>
            <p class="footer-slogan">Professional letters made simple</p>
          </div>
          <div class="footer-column">
            <h4>Links</h4>
            <ul>
              <li><a href="index.php">Home</a></li>
              <li><a href="index.php#how-it-works">How It Works</a></li>
              <li><a href="index.php#benefits">Benefits</a></li>
              <li><a href="index.php#pricing">Pricing</a></li>
              <li><a href="about.php">About Us</a></li>
              <!-- <li><a href="contact.php">Contact Us</a></li> -->
            </ul>
          </div>
          <div class="footer-column">
            <h4>Legal</h4>
            <ul>
              <li><a href="privacy-policy.php">Privacy Policy</a></li>
              <li><a href="terms-of-service.php">Terms of Service</a></li>
              <li><a href="cookie-policy.php">Cookie Policy</a></li>
              <li><a href="refund-policy.php">Refund Policy</a></li>
              <li>
                <a href="cancel-subscription.php">Cancel Subscription</a>
              </li>
            </ul>
          </div>
          <div class="footer-column">
            <h4>Contact</h4>
            <ul>
              <li><a href="contact.php">Contact Us</a></li>
              <li>
                <a href="mailto:support@letterliftapp.com"
                  >support@letterliftapp.com</a
                >
              </li>
              <li><a href="tel:+14243250598">+1 (424) 325-05-98</a></li>
              <li>
                1230 Rosecrans Ave Suite 300<br />Manhattan Beach, CA 90266
              </li>
            </ul>
          </div>
        </div>
        <div class="footer-bottom">
          <p>&copy; 2025 LetterLift. All rights reserved.</p>
          <p>LetterLift is a service of Noventra Consulting Group</p>
        </div>
      </div>
    </footer>

    <script src="js/main.js"></script>
  </body>
</html>
