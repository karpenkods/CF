<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>LetterLift</title>
    <link rel="icon" type="image/svg+xml" href="icons/favicon.webp" />
    <link rel="stylesheet" href="css/styles.css" />
  </head>
  <body>
    <!-- GDPR Banner -->
    <div id="gdpr-banner" class="gdpr-banner">
      <div class="gdpr-content">
        <div>
          <h4>We use cookies</h4>
          <p>
            This website uses cookies to improve your experience and analyze
            traffic. By continuing to use the site, you agree to our use of
            cookies.
            <a href="cookie-policy.php">Learn more</a>
          </p>
        </div>
        <div class="gdpr-buttons">
          <button id="accept-all" class="gdpr-btn accept">Accept All</button>
          <button id="customize" class="gdpr-btn customize">Customize</button>
          <button id="reject-all" class="gdpr-btn reject">Reject All</button>
        </div>
      </div>
    </div>

    <!-- Header -->
    <header class="header">
      <div class="container">
        <div class="header-content">
          <div class="logo">
            <a href="index.php">
              <img
                src="icons/logo-header.webp"
                alt="LetterLift"
                class="logo-img"
              />
            </a>
          </div>
          <nav class="nav">
            <ul class="nav-list">
              <li><a href="index.php">Home</a></li>
              <li><a href="index.php#how-it-works">How It Works</a></li>
              <li><a href="index.php#benefits">Benefits</a></li>
              <li><a href="index.php#pricing">Pricing</a></li>
              <li><a href="about.php">About Us</a></li>
            </ul>
          </nav>
          <div class="header-cta">
            <a href="index.php#pricing" class="btn btn-primary">Get Started</a>
          </div>
        </div>
      </div>
    </header>

    <!-- Terms of Service Content -->
    <main class="legal-page">
      <div class="container">
        <div class="legal-content">
          <h1>Terms of Service</h1>
          <p class="last-updated">Last Updated: April 8, 2025</p>

          <div class="legal-section">
            <h2>1. Agreement to Terms</h2>
            <p>
              These Terms of Service ("Terms") constitute a legally binding
              agreement between you ("User," "you," or "your") and Noventra
              Consulting Group ("Company," "we," "us," or "our"), the operator
              of LetterLift ("Service"). By accessing or using our Service, you
              agree to be bound by these Terms and our Privacy Policy,
              incorporated herein by reference.
            </p>

            <p>
              If you do not agree to these Terms, you may not access or use our
              Service. These Terms apply to all visitors, users, and others who
              access or use the Service.
            </p>
          </div>

          <div class="legal-section">
            <h2>2. Description of Service</h2>
            <p>
              LetterLift is a web-based platform that provides AI-powered tools
              and templates for creating professional motivational letters,
              cover letters, and other written communications. Our Service
              includes:
            </p>
            <ul>
              <li>Access to a library of professional letter templates</li>
              <li>AI-powered writing assistance and suggestions</li>
              <li>Customization tools for personalizing letters</li>
              <li>Document generation and download capabilities</li>
              <li>Customer support and guidance</li>
            </ul>
          </div>

          <div class="legal-section">
            <h2>3. Eligibility and Account Registration</h2>

            <h3>3.1 Age Requirements</h3>
            <p>
              You must be at least 18 years old to use our Service. By using the
              Service, you represent and warrant that you are at least 18 years
              old and have the legal capacity to enter into these Terms.
            </p>

            <h3>3.2 Account Creation</h3>
            <p>
              To access certain features of our Service, you must create an
              account. You agree to:
            </p>
            <ul>
              <li>
                Provide accurate, current, and complete information during
                registration
              </li>
              <li>Maintain and promptly update your account information</li>
              <li>
                Maintain the security and confidentiality of your login
                credentials
              </li>
              <li>
                Accept responsibility for all activities under your account
              </li>
              <li>
                Notify us immediately of any unauthorized use of your account
              </li>
            </ul>

            <h3>3.3 Account Termination</h3>
            <p>
              We reserve the right to suspend or terminate your account at any
              time for violation of these Terms or for any other reason at our
              sole discretion.
            </p>
          </div>

          <div class="legal-section">
            <h2>4. Subscription Plans and Pricing</h2>

            <p>
              LetterLift offers multiple subscription tiers organized into three
              levels to meet different user needs. All prices are in US Dollars
              and are subject to applicable taxes.
            </p>

            <h3>4.1 Basic Level Plans</h3>
            <div class="pricing-table">
              <div class="pricing-tier">
                <h4>Starter Plan - $1.99/month</h4>
                <ul>
                  <li>Access to 10+ basic templates</li>
                  <li>Simple writing tools</li>
                  <li>Up to 3 letters per month</li>
                  <li>Email support</li>
                </ul>
              </div>

              <div class="pricing-tier">
                <h4>Essential Plan - $9.99/month</h4>
                <ul>
                  <li>Access to 50+ professional templates</li>
                  <li>Basic AI writing assistance</li>
                  <li>Up to 15 letters per month</li>
                  <li>Priority email support</li>
                </ul>
              </div>

              <div class="pricing-tier">
                <h4>Standard Plan - $19.50/month</h4>
                <ul>
                  <li>Access to 100+ professional templates</li>
                  <li>Enhanced AI assistance</li>
                  <li>Up to 30 letters per month</li>
                  <li>Phone and email support</li>
                </ul>
              </div>

              <div class="pricing-tier">
                <h4>Plus Plan - $29.90/month</h4>
                <ul>
                  <li>Access to 150+ professional templates</li>
                  <li>Advanced AI writing tools</li>
                  <li>Up to 50 letters per month</li>
                  <li>Priority support with chat</li>
                </ul>
              </div>
            </div>

            <h3>4.2 Advanced Level Plans</h3>
            <div class="pricing-table">
              <div class="pricing-tier">
                <h4>Professional Plan - $39.99/month</h4>
                <ul>
                  <li>Access to 200+ professional templates</li>
                  <li>Advanced AI writing assistance</li>
                  <li>Up to 100 letters per month</li>
                  <li>Custom branding options</li>
                </ul>
              </div>

              <div class="pricing-tier">
                <h4>Premium Plan - $49.50/month</h4>
                <ul>
                  <li>Access to 300+ professional templates</li>
                  <li>Premium AI writing tools</li>
                  <li>Unlimited letters per month</li>
                  <li>Industry-specific templates</li>
                </ul>
              </div>

              <div class="pricing-tier">
                <h4>Business Plan - $59.90/month</h4>
                <ul>
                  <li>Access to 400+ business templates</li>
                  <li>Team collaboration tools</li>
                  <li>Unlimited letters per month</li>
                  <li>Advanced analytics</li>
                </ul>
              </div>

              <div class="pricing-tier">
                <h4>Corporate Plan - $69.99/month</h4>
                <ul>
                  <li>Access to 500+ corporate templates</li>
                  <li>Enterprise AI assistance</li>
                  <li>Unlimited everything</li>
                  <li>Dedicated account manager</li>
                </ul>
              </div>
            </div>

            <h3>4.3 Professional Level Plans</h3>
            <div class="pricing-table">
              <div class="pricing-tier">
                <h4>Executive Plan - $79.50/month</h4>
                <ul>
                  <li>Access to 600+ executive templates</li>
                  <li>Executive AI writing coach</li>
                  <li>Unlimited premium features</li>
                  <li>White-glove support</li>
                </ul>
              </div>

              <div class="pricing-tier">
                <h4>Enterprise Plan - $89.90/month</h4>
                <ul>
                  <li>Access to 700+ enterprise templates</li>
                  <li>Custom AI training</li>
                  <li>API access and integrations</li>
                  <li>On-site training available</li>
                </ul>
              </div>

              <div class="pricing-tier">
                <h4>Ultimate Plan - $99.99/month</h4>
                <ul>
                  <li>Access to 800+ premium templates</li>
                  <li>Personalized AI assistant</li>
                  <li>Custom template creation</li>
                  <li>24/7 priority support</li>
                </ul>
              </div>

              <div class="pricing-tier">
                <h4>Elite Plan - $109.50/month</h4>
                <ul>
                  <li>Access to 1000+ exclusive templates</li>
                  <li>Elite AI writing consultant</li>
                  <li>Bespoke solutions</li>
                  <li>Concierge-level service</li>
                </ul>
              </div>
            </div>
          </div>

          <h3>4.4 Billing and Payment Terms</h3>
          <ul>
            <li>All subscriptions are billed monthly in advance</li>
            <li>Prices are subject to change with 30 days' notice</li>
            <li>Payment is due immediately upon subscription activation</li>
            <li>Failed payments may result in service suspension</li>
            <li>
              All sales are final unless otherwise specified in our Refund
              Policy
            </li>
          </ul>
        </div>

        <div class="legal-section">
          <h2>5. User Conduct and Prohibited Uses</h2>

          <p>
            You agree not to use the Service for any unlawful purpose or in any
            way that could damage, disable, overburden, or impair the Service.
            Prohibited uses include:
          </p>

          <h3>5.1 Content Restrictions</h3>
          <ul>
            <li>
              Creating content that is illegal, harmful, threatening, abusive,
              or defamatory
            </li>
            <li>
              Generating content that infringes on intellectual property rights
            </li>
            <li>
              Creating fraudulent, misleading, or deceptive communications
            </li>
            <li>Producing content that violates privacy rights of others</li>
            <li>
              Generating content for spam, phishing, or other malicious purposes
            </li>
          </ul>

          <h3>5.2 Technical Restrictions</h3>
          <ul>
            <li>Attempting to gain unauthorized access to our systems</li>
            <li>
              Using automated tools to access the Service beyond normal usage
            </li>
            <li>
              Reverse engineering, decompiling, or disassembling our software
            </li>
            <li>Interfering with or disrupting the Service or servers</li>
            <li>Circumventing security measures or access controls</li>
          </ul>

          <h3>5.3 Commercial Restrictions</h3>
          <ul>
            <li>
              Reselling or redistributing our Service without authorization
            </li>
            <li>Using the Service to compete directly with our business</li>
            <li>Sharing account credentials with unauthorized users</li>
            <li>Exceeding usage limits specified in your subscription plan</li>
          </ul>
        </div>

        <div class="legal-section">
          <h2>6. Intellectual Property Rights</h2>

          <h3>6.1 Our Intellectual Property</h3>
          <p>
            The Service and its original content, features, and functionality
            are owned by Noventra Consulting Group and are protected by United
            States and international copyright, trademark, patent, trade secret,
            and other intellectual property laws.
          </p>

          <h3>6.2 User Content</h3>
          <p>
            You retain ownership of content you create using our Service.
            However, you grant us a limited, non-exclusive license to use your
            content for the purpose of providing and improving our Service.
          </p>

          <h3>6.3 Template Usage Rights</h3>
          <p>
            Your subscription grants you a non-exclusive, non-transferable right
            to use our templates for creating personal or business
            communications. You may not redistribute, resell, or share templates
            with non-subscribers.
          </p>
        </div>

        <div class="legal-section">
          <h2>7. Privacy and Data Protection</h2>

          <p>
            Your privacy is important to us. Our collection, use, and disclosure
            of your personal information is governed by our Privacy Policy,
            which is incorporated into these Terms by reference. By using our
            Service, you consent to the collection and use of your information
            as described in our Privacy Policy.
          </p>
        </div>

        <div class="legal-section">
          <h2>8. Service Availability and Modifications</h2>

          <h3>8.1 Service Availability</h3>
          <p>
            We strive to maintain high service availability but cannot guarantee
            uninterrupted access. The Service may be temporarily unavailable due
            to maintenance, updates, or technical issues.
          </p>

          <h3>8.2 Service Modifications</h3>
          <p>
            We reserve the right to modify, suspend, or discontinue any aspect
            of the Service at any time. We will provide reasonable notice of
            material changes when possible.
          </p>

          <h3>8.3 Updates and Upgrades</h3>
          <p>
            We may release updates, upgrades, or new features. Your continued
            use of the Service constitutes acceptance of such changes.
          </p>
        </div>

        <div class="legal-section">
          <h2>9. Termination</h2>

          <h3>9.1 Termination by You</h3>
          <p>
            You may terminate your account at any time by following the
            cancellation process outlined in our Refund Policy or by contacting
            customer support.
          </p>

          <h3>9.2 Termination by Us</h3>
          <p>
            We may terminate or suspend your account immediately, without prior
            notice, for conduct that we believe violates these Terms or is
            harmful to other users, us, or third parties.
          </p>

          <h3>9.3 Effect of Termination</h3>
          <p>
            Upon termination, your right to use the Service will cease
            immediately. We may delete your account and all associated data,
            though we may retain certain information as required by law or for
            legitimate business purposes.
          </p>
        </div>

        <div class="legal-section">
          <h2>10. Disclaimers and Limitations of Liability</h2>

          <h3>10.1 Service Disclaimers</h3>
          <p>
            THE SERVICE IS PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT
            WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT
            LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
            PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
          </p>

          <h3>10.2 Content Disclaimers</h3>
          <p>
            We do not warrant that the content generated through our Service
            will be accurate, complete, or suitable for your specific needs. You
            are responsible for reviewing and editing all content before use.
          </p>

          <h3>10.3 Limitation of Liability</h3>
          <p>
            TO THE MAXIMUM EXTENT PERMITTED BY LAW, IN NO EVENT SHALL NOVENTRA
            CONSULTING GROUP BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL,
            CONSEQUENTIAL, OR PUNITIVE DAMAGES, INCLUDING BUT NOT LIMITED TO
            LOSS OF PROFITS, DATA, USE, OR GOODWILL, ARISING OUT OF OR RELATING
            TO YOUR USE OF THE SERVICE.
          </p>

          <h3>10.4 Damage Cap</h3>
          <p>
            OUR TOTAL LIABILITY TO YOU FOR ALL CLAIMS ARISING OUT OF OR RELATING
            TO THESE TERMS OR THE SERVICE SHALL NOT EXCEED THE AMOUNT YOU PAID
            US IN THE TWELVE (12) MONTHS PRECEDING THE CLAIM.
          </p>
        </div>

        <div class="legal-section">
          <h2>11. Indemnification</h2>

          <p>
            You agree to indemnify, defend, and hold harmless Noventra
            Consulting Group, its officers, directors, employees, agents, and
            affiliates from and against any claims, liabilities, damages,
            losses, costs, expenses, or fees (including reasonable attorneys'
            fees) arising from:
          </p>
          <ul>
            <li>Your use or misuse of the Service</li>
            <li>Your violation of these Terms</li>
            <li>Your violation of any rights of another party</li>
            <li>Content you create or submit through the Service</li>
          </ul>
        </div>

        <div class="legal-section">
          <h2>12. Dispute Resolution</h2>

          <h3>12.1 Governing Law</h3>
          <p>
            These Terms shall be governed by and construed in accordance with
            the laws of the State of California, without regard to its conflict
            of law principles.
          </p>

          <h3>12.2 Jurisdiction</h3>
          <p>
            Any legal action or proceeding arising under these Terms will be
            brought exclusively in the federal or state courts located in Los
            Angeles County, California, and you hereby consent to personal
            jurisdiction and venue therein.
          </p>

          <h3>12.3 Arbitration</h3>
          <p>
            Any dispute arising out of or relating to these Terms or the Service
            shall be resolved through binding arbitration in accordance with the
            Commercial Arbitration Rules of the American Arbitration
            Association.
          </p>

          <h3>12.4 Class Action Waiver</h3>
          <p>
            You agree that any arbitration or legal proceeding shall be limited
            to the dispute between us and you individually. You waive any right
            to participate in a class action lawsuit or class-wide arbitration.
          </p>
        </div>

        <div class="legal-section">
          <h2>13. General Provisions</h2>

          <h3>13.1 Entire Agreement</h3>
          <p>
            These Terms, together with our Privacy Policy and any other legal
            notices published by us on the Service, constitute the entire
            agreement between you and us concerning the Service.
          </p>

          <h3>13.2 Severability</h3>
          <p>
            If any provision of these Terms is found to be unenforceable or
            invalid, that provision will be limited or eliminated to the minimum
            extent necessary so that these Terms will otherwise remain in full
            force and effect.
          </p>

          <h3>13.3 Assignment</h3>
          <p>
            You may not assign or transfer these Terms or your rights hereunder,
            in whole or in part, without our written consent. We may assign
            these Terms at any time without notice.
          </p>

          <h3>13.4 Waiver</h3>
          <p>
            No waiver of any term of these Terms shall be deemed a further or
            continuing waiver of such term or any other term, and our failure to
            assert any right or provision under these Terms shall not constitute
            a waiver of such right or provision.
          </p>

          <h3>13.5 Force Majeure</h3>
          <p>
            We shall not be liable for any failure or delay in performance under
            these Terms which is due to fire, flood, earthquake, elements of
            nature, acts of God, acts of war, terrorism, riots, civil disorders,
            rebellions, or other similar causes beyond our reasonable control.
          </p>
        </div>

        <div class="legal-section">
          <h2>14. Contact Information</h2>

          <p>If you have any questions about these Terms, please contact us:</p>

          <div class="contact-details">
            <p>
              <strong>Noventra Consulting Group</strong><br />
              Attention: Legal Department<br />
              1230 Rosecrans Ave Suite 300<br />
              Manhattan Beach, CA 90266
            </p>

            <p>
              <strong>Email:</strong>
              <a href="mailto:support@letterliftapp.com"
                >support@letterliftapp.com</a
              ><br />
              <strong>Phone:</strong>
              <a href="tel:+14243250598">+1 (424) 325-05-98</a><br />
              <strong>Business Hours:</strong> Monday to Friday, 9AM to 6PM EST
            </p>
          </div>
        </div>

        <div class="legal-section">
          <h2>15. Effective Date</h2>

          <p>
            These Terms of Service are effective as of April 8, 2025, and will
            remain in effect until modified or terminated in accordance with
            these Terms.
          </p>
        </div>
      </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
      <div class="container">
        <div class="footer-content">
          <div class="footer-brand">
            <a href="index.php">
              <img
                src="icons/logo-footer.webp"
                alt="LetterLift"
                class="footer-logo"
              />
            </a>
            <p class="footer-slogan">Professional letters made simple</p>
          </div>
          <div class="footer-column">
            <h4>Links</h4>
            <ul>
              <li><a href="index.php">Home</a></li>
              <li><a href="index.php#how-it-works">How It Works</a></li>
              <li><a href="index.php#benefits">Benefits</a></li>
              <li><a href="index.php#pricing">Pricing</a></li>
              <li><a href="about.php">About Us</a></li>
              <!-- <li><a href="contact.php">Contact Us</a></li> -->
            </ul>
          </div>
          <div class="footer-column">
            <h4>Legal</h4>
            <ul>
              <li><a href="privacy-policy.php">Privacy Policy</a></li>
              <li><a href="terms-of-service.php">Terms of Service</a></li>
              <li><a href="cookie-policy.php">Cookie Policy</a></li>
              <li><a href="refund-policy.php">Refund Policy</a></li>
              <li>
                <a href="cancel-subscription.php">Cancel Subscription</a>
              </li>
            </ul>
          </div>
          <div class="footer-column">
            <h4>Contact</h4>
            <ul>
              <li><a href="contact.php">Contact Us</a></li>
              <li>
                <a href="mailto:support@letterliftapp.com"
                  >support@letterliftapp.com</a
                >
              </li>
              <li><a href="tel:+14243250598">+1 (424) 325-05-98</a></li>
              <li>
                1230 Rosecrans Ave Suite 300<br />Manhattan Beach, CA 90266
              </li>
            </ul>
          </div>
        </div>
        <div class="footer-bottom">
          <p>&copy; 2025 LetterLift. All rights reserved.</p>
          <p>LetterLift is a service of Noventra Consulting Group</p>
        </div>
      </div>
    </footer>

    <script src="js/main.js"></script>
  </body>
</html>
